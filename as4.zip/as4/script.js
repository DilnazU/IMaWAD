const diceImages = [
  "images/dice-six-faces-one.svg",
  "images/dice-six-faces-two.svg",
  "images/dice-six-faces-three.svg",
  "images/dice-six-faces-four.svg",
  "images/dice-six-faces-five.svg",
  "images/dice-six-faces-six.svg",
];

let rollCount = 0;

document.getElementById("rollButton").addEventListener("click", () => {
  document.getElementById("winwin").textContent = "";
  const dice1Roll = Math.floor(Math.random() * 6) + 1;
  const dice2Roll = Math.floor(Math.random() * 6) + 1;

  document.getElementById("dice1").src = diceImages[dice1Roll - 1];
  document.getElementById("dice2").src = diceImages[dice2Roll - 1];

  rollCount++;
  document.getElementById("counter").textContent = `Roll count: ${rollCount}`;

  const sum = dice1Roll + dice2Roll;
  document.getElementById("result").textContent = `Sum: ${sum}`;

  if (dice1Roll === dice2Roll) {
    document.getElementById("winwin").textContent += "🎉🎉🎉";
  }
});
